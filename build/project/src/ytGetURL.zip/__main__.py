#!/usr/bin/python
# -*- coding: utf-8 -*- 
'''
Created on Jan 2, 2015

@author: jkarnuta

LICENSE: GNU GPL. See Licenses/COPYING for more

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

'''
import sys
import re
import urllib2
import BeautifulSoup
import time


yt_url = ""

def get_URL_main():
    """
    gets youtube url from user input
    """
    global yt_url
    yt_url = get_yt_URL()
    print "[ytURL] "+yt_url

    #prompts user for input, retrieves URL address for song name 
def get_yt_URL():
    #Define Fields and Constants
    global number_videos
    global song_info
    global yt_id
    global song_meta
    global yt_duration
    
    #make song_meta sys.argv = ["script name","song","artist","option"]
    indexes = [0,1,2]
    song_meta = [sys.argv[i+1] for i in indexes]
    youtube_url_search = "https://www.youtube.com/results?search_query="
    youtube_results_id = "section-list"
    begin_time = time.time()
    song_meta = [x.strip() for x in song_meta]
    song_info = song_meta[0]+" "+song_meta[1]

    #remove text within brackets --> [TEXT] 
    song_meta[0] = re.sub("\[.*?\]","",song_meta[0])
    song_meta[1] = re.sub("\[.*?\]","",song_meta[1])
    
    if song_meta[2] != "":
        if "ytid" in song_meta[2]:
            id_list = [x.strip() for x in song_meta[2].split("=")]
            yt_id = id_list[1]
            yt_duration = "-:--"
            return "https://www.youtube.com/watch?v="+yt_id  
        else:
            print "ytid not in third argument..."
            print "Exiting ytAudio"
            sys.exit(1)
            
    #---------------- System Exiting Block
    if not song_info:
        print("no song entered, exiting")
        raise SystemExit(0) # 0 == exited without error 
    #----------------
    
    print "fetching youtube video IDs..."
    
    #get webpage HTML
    #convert spaces to url %20 
    urlToGet = re.sub(" ", "%20", youtube_url_search+song_info)
    getHTML = urllib2.urlopen(urlToGet).read()
    
    #yt_id is the youtube video id of the most relevant video
    #yt_duration is the length of the most relevant video
    #resultHTML = HTML tag from id = youtube_results_id
    soup = BeautifulSoup.BeautifulSoup(getHTML)

    yt_tuple = renderHTML(str(soup.find("ol",{"class":youtube_results_id}))) #(yt_id, yt_duration)
    yt_id = yt_tuple[0]
    yt_duration = yt_tuple[1]

    print str(number_videos) +" youtube urls fetched in "+diff_time(begin_time)+"s"
    return "https://www.youtube.com/watch?v="+yt_id

    
#returns the first occurrence of the text located between sand and wich
def renderHTML(inner_HTML):
    #use regex for sandwich
    #first part of tuple. Return youtube_id of first video
    #result contained in video_list[0]
    global number_videos
    sand = "data-context-item-id=\""
    wich = "\""
    video_list = re.findall(sand+"(.*?)"+wich, inner_HTML)
    number_videos = len(video_list)
    
    sand = "Duration:"
    wich = "\.<"
    duration_list = re.findall(sand+"(.*?)"+wich, inner_HTML)
    return (video_list[0],duration_list[0].strip())

"""
returns the formatted difference between current time and old_time
format: 0.0000s
"""
def diff_time(old_time):
    diff = getTime() - old_time
    return "{0:.4f}".format((diff*100)/100)

"""
gets current system time
"""
def getTime():
    return time.time()

if __name__ == "__main__":
    get_URL_main()